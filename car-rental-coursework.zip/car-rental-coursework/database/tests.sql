SET search_path TO car_rental;

-- Тест 1: уникальный телефон
INSERT INTO clients(last_name,first_name,address,phone)
VALUES ('Тест','Клиент','Москва','+79991111111');

-- Тест 2: корректная сделка
INSERT INTO rentals(client_id,car_id,issue_date,expected_return_date)
VALUES (2,2,CURRENT_DATE+10,CURRENT_DATE+12);

-- Тест 3: возврат
CALL process_return(1, CURRENT_DATE + 4);

-- Тест 4: отчёт
SELECT * FROM get_revenue_report(CURRENT_DATE - 30, CURRENT_DATE + 30);
