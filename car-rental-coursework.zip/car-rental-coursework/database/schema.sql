-- АИС «Прокат автомобилей»
DROP SCHEMA IF EXISTS car_rental CASCADE;
CREATE SCHEMA car_rental;
SET search_path TO car_rental;

CREATE TABLE clients (
    client_id SERIAL PRIMARY KEY,
    last_name VARCHAR(50) NOT NULL,
    first_name VARCHAR(50) NOT NULL,
    middle_name VARCHAR(50),
    address VARCHAR(200) NOT NULL,
    phone VARCHAR(20) NOT NULL UNIQUE
);

CREATE TABLE cars (
    car_id SERIAL PRIMARY KEY,
    plate_number VARCHAR(15) NOT NULL UNIQUE,
    brand VARCHAR(50) NOT NULL,
    model VARCHAR(50) NOT NULL,
    car_type VARCHAR(50) NOT NULL,
    daily_price NUMERIC(12,2) NOT NULL CHECK (daily_price > 0),
    production_year INT NOT NULL CHECK (production_year BETWEEN 1900 AND EXTRACT(YEAR FROM CURRENT_DATE)::INT + 1),
    status VARCHAR(20) NOT NULL DEFAULT 'available'
        CHECK (status IN ('available','rented','service'))
);

CREATE TABLE discounts (
    discount_id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    percent NUMERIC(5,2) NOT NULL CHECK (percent BETWEEN 0 AND 100),
    condition_text VARCHAR(200) NOT NULL
);

CREATE TABLE rentals (
    rental_id SERIAL PRIMARY KEY,
    client_id INT NOT NULL REFERENCES clients(client_id) ON DELETE RESTRICT,
    car_id INT NOT NULL REFERENCES cars(car_id) ON DELETE RESTRICT,
    issue_date DATE NOT NULL,
    expected_return_date DATE NOT NULL,
    actual_return_date DATE,
    base_cost NUMERIC(12,2) NOT NULL DEFAULT 0 CHECK (base_cost >= 0),
    discount_id INT REFERENCES discounts(discount_id),
    total_cost NUMERIC(12,2) NOT NULL DEFAULT 0 CHECK (total_cost >= 0),
    status VARCHAR(20) NOT NULL DEFAULT 'active'
        CHECK (status IN ('active','closed','cancelled')),
    CHECK (expected_return_date >= issue_date),
    CHECK (actual_return_date IS NULL OR actual_return_date >= issue_date)
);

CREATE TABLE fines (
    fine_id SERIAL PRIMARY KEY,
    rental_id INT NOT NULL REFERENCES rentals(rental_id) ON DELETE CASCADE,
    violation_type VARCHAR(200) NOT NULL,
    amount NUMERIC(12,2) NOT NULL CHECK (amount > 0),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    paid BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE INDEX idx_rentals_client ON rentals(client_id);
CREATE INDEX idx_rentals_car ON rentals(car_id);
CREATE INDEX idx_rentals_dates ON rentals(car_id, issue_date, expected_return_date);

CREATE OR REPLACE FUNCTION check_car_availability()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.status = 'active' AND EXISTS (
        SELECT 1 FROM rentals r
        WHERE r.car_id = NEW.car_id
          AND r.rental_id <> COALESCE(NEW.rental_id, -1)
          AND r.status = 'active'
          AND daterange(r.issue_date, r.expected_return_date, '[]')
              && daterange(NEW.issue_date, NEW.expected_return_date, '[]')
    ) THEN
        RAISE EXCEPTION 'Автомобиль уже занят в выбранный период';
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_check_car_availability
BEFORE INSERT OR UPDATE OF car_id, issue_date, expected_return_date, status
ON rentals
FOR EACH ROW EXECUTE FUNCTION check_car_availability();

CREATE OR REPLACE FUNCTION calculate_rental_cost()
RETURNS TRIGGER AS $$
DECLARE
    v_price NUMERIC(12,2);
    v_discount NUMERIC(5,2) := 0;
    v_days INT;
BEGIN
    SELECT daily_price INTO v_price FROM cars WHERE car_id = NEW.car_id;
    IF NEW.discount_id IS NOT NULL THEN
        SELECT percent INTO v_discount FROM discounts WHERE discount_id = NEW.discount_id;
    END IF;
    v_days := (NEW.expected_return_date - NEW.issue_date) + 1;
    NEW.base_cost := ROUND(v_price * v_days, 2);
    NEW.total_cost := ROUND(NEW.base_cost * (1 - v_discount / 100), 2);
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_calculate_rental_cost
BEFORE INSERT OR UPDATE OF car_id, issue_date, expected_return_date, discount_id
ON rentals
FOR EACH ROW EXECUTE FUNCTION calculate_rental_cost();

CREATE OR REPLACE FUNCTION update_car_status()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.status = 'active' THEN
        UPDATE cars SET status = 'rented' WHERE car_id = NEW.car_id;
    ELSIF NEW.status IN ('closed','cancelled') THEN
        IF NOT EXISTS (SELECT 1 FROM rentals WHERE car_id = NEW.car_id AND status = 'active') THEN
            UPDATE cars SET status = 'available' WHERE car_id = NEW.car_id;
        END IF;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_update_car_status
AFTER INSERT OR UPDATE OF status ON rentals
FOR EACH ROW EXECUTE FUNCTION update_car_status();

CREATE OR REPLACE PROCEDURE process_return(p_rental_id INT, p_return_date DATE)
LANGUAGE plpgsql AS $$
DECLARE
    v_expected DATE;
BEGIN
    SELECT expected_return_date INTO v_expected
    FROM rentals WHERE rental_id = p_rental_id AND status = 'active';

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Активная сделка не найдена';
    END IF;

    UPDATE rentals
    SET actual_return_date = p_return_date, status = 'closed'
    WHERE rental_id = p_rental_id;

    IF p_return_date > v_expected THEN
        INSERT INTO fines(rental_id, violation_type, amount)
        VALUES (p_rental_id, 'Просрочка возврата',
                (p_return_date - v_expected) * 1000);
    END IF;
END;
$$;

CREATE OR REPLACE FUNCTION get_revenue_report(p_from DATE, p_to DATE)
RETURNS TABLE (
    rentals_count BIGINT,
    revenue NUMERIC,
    fines_amount NUMERIC
) AS $$
BEGIN
    RETURN QUERY
    SELECT COUNT(*)::BIGINT,
           COALESCE(SUM(r.total_cost),0),
           COALESCE(SUM(f.amount),0)
    FROM rentals r
    LEFT JOIN fines f ON f.rental_id = r.rental_id
    WHERE r.issue_date BETWEEN p_from AND p_to;
END;
$$ LANGUAGE plpgsql;

CREATE VIEW v_car_rent_summary AS
SELECT c.car_id, c.plate_number, c.brand, c.model,
       COUNT(r.rental_id) AS rentals_count,
       COALESCE(SUM(r.total_cost),0) AS revenue
FROM cars c
LEFT JOIN rentals r ON r.car_id = c.car_id
GROUP BY c.car_id, c.plate_number, c.brand, c.model;

CREATE ROLE rental_employee NOLOGIN;
CREATE ROLE rental_manager NOLOGIN;
CREATE ROLE rental_db_admin NOLOGIN;

GRANT USAGE ON SCHEMA car_rental TO rental_employee, rental_manager, rental_db_admin;
GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA car_rental TO rental_employee;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA car_rental TO rental_employee;
GRANT SELECT ON ALL TABLES IN SCHEMA car_rental TO rental_manager;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA car_rental TO rental_db_admin;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA car_rental TO rental_db_admin;
