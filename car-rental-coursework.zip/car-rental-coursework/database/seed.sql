SET search_path TO car_rental;

INSERT INTO clients(last_name,first_name,middle_name,address,phone) VALUES
('Иванов','Иван','Сергеевич','Москва, ул. Ленина, 10','+79990000001'),
('Петров','Пётр','Алексеевич','Москва, ул. Мира, 20','+79990000002');

INSERT INTO cars(plate_number,brand,model,car_type,daily_price,production_year) VALUES
('A123AA77','Toyota','Camry','Седан',5000,2022),
('B456BB77','BMW','X5','Кроссовер',8500,2023),
('C789CC77','Kia','Rio','Седан',3000,2021);

INSERT INTO discounts(name,percent,condition_text) VALUES
('Постоянный клиент',10,'Для постоянных клиентов'),
('Длительная аренда',15,'Аренда более 14 дней');

INSERT INTO rentals(client_id,car_id,issue_date,expected_return_date,discount_id)
VALUES (1,1,CURRENT_DATE,CURRENT_DATE+2,1);

SELECT * FROM v_car_rent_summary;
SELECT * FROM get_revenue_report(CURRENT_DATE - 30, CURRENT_DATE + 30);
