DROP SCHEMA IF EXISTS car_rental CASCADE;
DROP ROLE IF EXISTS rental_employee;
DROP ROLE IF EXISTS rental_manager;
DROP ROLE IF EXISTS rental_db_admin;
